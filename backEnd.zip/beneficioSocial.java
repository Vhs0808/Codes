import java.util.Scanner; // Importar scanner
import javax.swing.JOptionPane;

public class beneficioSocial {
  
  public static void main (String[] args) {
    // Ler entrada do usuário
        Scanner scanner = new Scanner(System.in);


    // Variáveis
       float rendaPessoa;
       float dependentesPessoa;
      
    // Executando o Código
       dependentesPessoa = Integer.parseInt(JOptionPane.showInputDialog("Insira a quantidade de dependentes: "));

       rendaPessoa = Integer.parseInt(JOptionPane.showInputDialog("Insira sua renda mensal: "));

        if (rendaPessoa <= 1500) {
        JOptionPane.showMessageDialog(null, "Classe Baixa - tem direito ao benefício.");
       

       } else if  (rendaPessoa <= 3500 && dependentesPessoa > 3) {
            JOptionPane.showMessageDialog(null, "Classe Baixa - tem direito ao benefício.");
            
       } else if  (rendaPessoa <= 3500 && dependentesPessoa <=3) {
            JOptionPane.showMessageDialog(null, "Classe média baixa - análise de elegibilidade");
       }
       
       else if  (rendaPessoa <= 7500 && dependentesPessoa >3) {
        JOptionPane.showMessageDialog(null, "Classe média baixa - análise de elegibilidade");
        
       }else if  (rendaPessoa <= 7500 && dependentesPessoa <=3) {
        JOptionPane.showMessageDialog(null, "Classe Média - Sem direito ao benefício.");
        
       }
       else if  (rendaPessoa > 7500 && dependentesPessoa > 3 ) {
        JOptionPane.showMessageDialog(null, "Classe Média - Sem direito ao benefício.");
       
       }else {
        JOptionPane.showMessageDialog(null, "Classe Alta - Sem direito ao benefício");
       
        
       }
      // Fechar o scanner
      scanner.close();
      }
    }
