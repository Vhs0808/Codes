import java.util.Scanner; // Importar scanner
import javax.swing.JOptionPane; // Importe de "Janelinha"

public class rebanhoOvelhas {
    public static void main (String[] args) {
    // Ler entrada do usuário
        Scanner scanner = new Scanner(System.in);
    

    // Variáveis

    int branca, marrom, negra, outraCor;
    int valorBrancas, valorMarrons, valorNegras, valorOutra;
    int quantiaOvelhas;
    float valorTotal;
    
    
    
    // Executando o Código

    branca = Integer.parseInt(JOptionPane.showInputDialog("Insira a quantia de ovelhas brancas: "));
    marrom = Integer.parseInt(JOptionPane.showInputDialog("Insira a quantia de ovelhas marrons: "));
    negra = Integer.parseInt(JOptionPane.showInputDialog("Insira a quantia de ovelhas negras: "));
    outraCor = Integer.parseInt(JOptionPane.showInputDialog("Insira a quantia de ovelhas outras cores: "));


    
    // Calculos de valores de ovelhas
    valorBrancas = branca * 250 ;

    valorMarrons = marrom * 200 ;

    valorNegras = negra * 300 ;

    valorOutra = outraCor * 180 ;
    

    // Valor de cada Ovelhas e Quantia
    JOptionPane.showMessageDialog(null, "Usada para produção de lã (Brancas) Quantia: " + branca + ("\n Valor em dinheiro: R$" + valorBrancas) ) ;
    JOptionPane.showMessageDialog(null, "Para estudo genético (Negras) Quantia: " + negra + ("\n Valor em dinheiro: R$" + valorNegras));
    JOptionPane.showMessageDialog(null, "Para venda (Marrons) Quantia: " + marrom + ("\n Valor em dinheiro: R$" + valorMarrons));
    JOptionPane.showMessageDialog(null, "Para avaliação (Outras cores) Quantia: " + outraCor + ("\n Valor em dinheiro: R$" + valorOutra));



    //Total de ovelhas
    quantiaOvelhas = branca + marrom + negra + outraCor;
    JOptionPane.showMessageDialog(null, "A quantia total das ovelhas é de: " + quantiaOvelhas);


    //Valor de todas as Ovelhas

    valorTotal = valorBrancas + valorMarrons + valorNegras + valorOutra;
    JOptionPane.showMessageDialog(null, "O valor total em dinheiro das ovelhas é de: R$" + valorTotal);



        // Fechar o scanner
        scanner.close();

}   
}




//* 


