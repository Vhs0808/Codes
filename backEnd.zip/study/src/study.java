import java.util.Scanner;

public class study {
    public static void main(String[] args) {




// ABERTURA SCANER

        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in)
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);



//SYSOUT - imprimir no console


        System.out.println("null");
        sysout




        
       

            sc.close();
        }
    }

